import httpx
import os
from dotenv import load_dotenv

load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

async def fetch_and_summarize_ai_news():
    # 1. Get recent AI news (via Google News RSS or any public source)
    news_url = "https://newsapi.org/v2/everything?q=artificial+intelligence&from=today&sortBy=publishedAt&apiKey=YOUR_NEWS_API"
    # Temporarily mocked for demo
    mock_news = """
    1. OpenAI released a new Code Interpreter upgrade.
    2. Meta launched Llama 3.5 with better accuracy.
    3. Google DeepMind announced Gemini 1.5 Flash.
    """

    # Uncomment the next line to always use the mock for now:
    return mock_news.strip()

    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={GEMINI_API_KEY}"
    headers = {"Content-Type": "application/json"}
    data = {
        "contents": [{
            "parts": [{
                "text": f"Summarize this AI news in simple words:\n\n{mock_news}"
            }]
        }]
    }

    async with httpx.AsyncClient() as client:
        response = await client.post(url, json=data, headers=headers)
        resp_json = response.json()
        if 'candidates' in resp_json:
            summary = resp_json['candidates'][0]['content']['parts'][0]['text']
            return summary
        else:
            # Return the error message from the API or a default message
            return f"Error from Gemini API: {resp_json.get('error', 'Unknown error')}"
