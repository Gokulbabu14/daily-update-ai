import os
import httpx
from fastapi import APIRouter, Query
from dotenv import load_dotenv

router = APIRouter()
load_dotenv()
NEWSAPI_KEY = os.getenv("NEWSAPI_KEY")

# Mock data for each section (multiple news items)
MOCK_DATA = {
    "today": {
        "news": [
            {
                "title": "OpenAI releases new Code Interpreter",
                "summary": "OpenAI has released a new upgrade to its Code Interpreter, making it more powerful and user-friendly.",
                "image_url": "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80"
            },
            {
                "title": "Meta launches Llama 3.5",
                "summary": "Meta's new Llama 3.5 model improves accuracy and efficiency for AI tasks.",
                "image_url": "https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=600&q=80"
            },
            {
                "title": "Google DeepMind announces Gemini 1.5 Flash",
                "summary": "Gemini 1.5 Flash is designed for faster, more efficient AI computations.",
                "image_url": "https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?auto=format&fit=crop&w=600&q=80"
            }
        ]
    },
    "yesterday": {
        "news": [
            {
                "title": "Anthropic introduces Claude 3.0",
                "summary": "Claude 3.0 brings new features and improved safety for conversational AI.",
                "image_url": "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=600&q=80"
            },
            {
                "title": "Microsoft announces new Azure AI features",
                "summary": "Microsoft Azure AI gets a boost with new tools for developers.",
                "image_url": "https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=600&q=80"
            }
        ]
    },
    "tomorrow": {
        "news": [
            {
                "title": "Google I/O to reveal new AI tools",
                "summary": "Expect major announcements from Google I/O about upcoming AI technologies.",
                "image_url": "https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?auto=format&fit=crop&w=600&q=80"
            },
            {
                "title": "New AI research papers to be published",
                "summary": "Tomorrow will see the release of several groundbreaking AI research papers.",
                "image_url": "https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=600&q=80"
            }
        ]
    },
    "future_plan": {
        "news": [
            {
                "title": "Integrate more real-time news sources",
                "summary": "Plans are underway to add more real-time news sources to the platform.",
                "image_url": "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=600&q=80"
            },
            {
                "title": "Add user customization",
                "summary": "Future updates will allow users to customize their news feed.",
                "image_url": "https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=600&q=80"
            }
        ]
    },
    "upcoming": {
        "news": [
            {
                "title": "AI conference next week",
                "summary": "A major AI conference is scheduled for next week with top speakers.",
                "image_url": "https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=600&q=80"
            },
            {
                "title": "New GPT-5 rumors",
                "summary": "Rumors suggest GPT-5 may be announced soon with significant improvements.",
                "image_url": "https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?auto=format&fit=crop&w=600&q=80"
            }
        ]
    },
    "help": {
        "news": [
            {
                "title": "Need help?",
                "summary": "Contact support@aiupdate.com or visit our FAQ page for assistance.",
                "image_url": "https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=600&q=80"
            }
        ]
    },
}

async def fetch_newsapi_ai_news(query=None):
    url = "https://newsapi.org/v2/everything"
    params = {
        "q": query or "artificial intelligence OR AI OR machine learning OR deep learning",
        "sortBy": "publishedAt",
        "language": "en",
        "apiKey": NEWSAPI_KEY,
        "pageSize": 10
    }
    async with httpx.AsyncClient() as client:
        resp = await client.get(url, params=params)
        data = resp.json()
        news = []
        for article in data.get("articles", []):
            news.append({
                "title": article["title"],
                "summary": article["description"] or "No summary available.",
                "image_url": article["urlToImage"] or "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80"
            })
        return news

@router.get("/today")
async def get_today(q: str = Query(None, description="Search query")):
    if NEWSAPI_KEY:
        try:
            news = await fetch_newsapi_ai_news(q)
            if news:
                return {"news": news}
        except Exception as e:
            pass  # fallback to mock
    # fallback to mock data
    if q:
        filtered = [item for item in MOCK_DATA["today"]["news"] if q.lower() in item["title"].lower() or q.lower() in item["summary"].lower()]
        return {"news": filtered}
    return MOCK_DATA["today"]

@router.get("/yesterday")
async def get_yesterday():
    return MOCK_DATA["yesterday"]

@router.get("/tomorrow")
async def get_tomorrow():
    return MOCK_DATA["tomorrow"]

@router.get("/future-plan")
async def get_future_plan():
    return MOCK_DATA["future_plan"]

@router.get("/upcoming")
async def get_upcoming():
    return MOCK_DATA["upcoming"]

@router.get("/help")
async def get_help():
    return MOCK_DATA["help"]

@router.get("/daily-updates")
async def get_daily_ai_updates():
    return MOCK_DATA["today"]
