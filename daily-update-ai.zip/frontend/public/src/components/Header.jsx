import React from 'react';

const Header = () => (
  <header className="text-center py-6">
    <h1 className="text-4xl font-bold text-gray-800">🧠 Daily AI Update</h1>
    <p className="text-gray-500">Summarized AI news powered by Gemini</p>
  </header>
);

export default Header;
