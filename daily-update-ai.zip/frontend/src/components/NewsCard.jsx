import React from 'react';

const NewsCard = ({ title, text, imageUrl, dateTime }) => (
  <div
    style={{
      maxWidth: 600,
      margin: "40px auto 32px auto",
      background: "rgba(255,255,255,0.95)",
      borderRadius: 24,
      boxShadow: "0 8px 32px rgba(0,0,0,0.10)",
      padding: "2.5rem 2rem 2rem 2rem",
      fontFamily: "'San Francisco', 'Inter', Arial, sans-serif",
      border: "1px solid #eaeaea",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
    }}
  >
    {imageUrl && (
      <img
        src={imageUrl}
        alt={title || "AI News"}
        style={{
          width: 120,
          height: 120,
          objectFit: "cover",
          borderRadius: 18,
          marginBottom: 24,
          boxShadow: "0 4px 16px rgba(80,80,160,0.10)",
        }}
      />
    )}
    {title && (
      <h2 style={{
        fontSize: "1.5rem",
        fontWeight: 700,
        marginBottom: "0.75rem",
        color: "#222",
        textAlign: "center"
      }}>
        {title}
      </h2>
    )}
    <p style={{
      color: "#444",
      fontSize: "1.15rem",
      lineHeight: 1.7,
      whiteSpace: "pre-line",
      textAlign: "center"
    }}>
      {text}
    </p>
    {dateTime && (
      <div style={{
        marginTop: 24,
        color: "#888",
        fontSize: 15,
        fontWeight: 500,
        letterSpacing: 0.2,
        textAlign: "center"
      }}>
        {dateTime}
      </div>
    )}
  </div>
);

export default NewsCard; 