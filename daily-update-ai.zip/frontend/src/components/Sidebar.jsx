import React from "react";

const options = [
  { key: "home", label: "Home" },
  { key: "today", label: "Today's Updates" },
  { key: "yesterday", label: "Yesterday" },
  { key: "tomorrow", label: "Tomorrow" },
  { key: "future-plan", label: "Future Plan" },
  { key: "upcoming", label: "Upcoming" },
  { key: "help", label: "Help" },
];

const Sidebar = ({ selected, onSelect }) => (
  <nav
    style={{
      width: 260,
      minHeight: "100vh",
      background: "#fff",
      color: "#222",
      display: "flex",
      flexDirection: "column",
      padding: "2.5rem 1.5rem 2rem 1.5rem",
      boxShadow: "2px 0 16px rgba(80,80,160,0.08)",
      position: "fixed",
      left: 0,
      top: 0,
      zIndex: 10,
    }}
  >
    <div style={{ display: 'flex', alignItems: 'center', marginBottom: 18 }}>
      <img src="/xerago-logo.png" alt="Xerago Logo" style={{ width: 48, height: 48, marginRight: 14 }} />
      <div>
        <div style={{ fontWeight: 800, fontSize: 22, letterSpacing: -1, color: "#1a7f5a" }}>XERAGO</div>
        <div style={{ fontSize: 13, color: "#888", fontWeight: 500, marginTop: 2 }}>The Science of Digital</div>
      </div>
    </div>
    <div style={{ margin: "32px 0" }}>
      {options.map((opt) => (
        <button
          key={opt.key}
          onClick={() => onSelect(opt.key)}
          style={{
            background: selected === opt.key ? "rgba(26,127,90,0.08)" : "none",
            color: "#222",
            border: "none",
            borderRadius: 10,
            padding: "0.85rem 1.2rem",
            marginBottom: 10,
            fontSize: 17,
            fontWeight: selected === opt.key ? 700 : 500,
            cursor: "pointer",
            width: "100%",
            textAlign: "left",
            transition: "background 0.2s, color 0.2s",
            outline: "none",
          }}
        >
          {opt.label}
        </button>
      ))}
    </div>
  </nav>
);

export default Sidebar; 