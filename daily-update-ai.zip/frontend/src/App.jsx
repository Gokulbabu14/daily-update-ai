import React, { useEffect, useState } from "react";
import Sidebar from "./components/Sidebar";
import NewsCard from "./components/NewsCard";

const appStyle = {
  minHeight: "100vh",
  background: "#f6f8fa",
  fontFamily: "'Inter', 'San Francisco', Arial, sans-serif",
  padding: 0,
  margin: 0,
  display: "flex",
};

const mainStyle = {
  marginLeft: 260,
  width: "100%",
  minHeight: "100vh",
  padding: "0 0 0 0",
  background: "#f6f8fa",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
};

const contentBoxStyle = {
  marginTop: 48,
  background: "#fff",
  borderRadius: 18,
  boxShadow: "0 4px 32px rgba(80,80,160,0.07)",
  padding: "2.5rem 2.5rem 2rem 2.5rem",
  maxWidth: 800,
  width: "100%",
  minHeight: 320,
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
};

const headerStyle = {
  textAlign: "center",
  fontSize: "2.7rem",
  fontWeight: 900,
  letterSpacing: "-1px",
  color: "#1a7f5a",
  marginBottom: "0.5rem",
  fontFamily: "'Inter', 'San Francisco', Arial, sans-serif",
};

const subHeaderStyle = {
  textAlign: "center",
  color: "#555",
  fontSize: "1.15rem",
  marginBottom: "2.5rem",
  fontWeight: 500,
  letterSpacing: 0.1,
};

const searchBarStyle = {
  display: "flex",
  justifyContent: "center",
  margin: "32px 0 12px 0",
};

const searchInputStyle = {
  width: 340,
  padding: "0.75rem 1.2rem",
  borderRadius: 18,
  border: "1.5px solid #b3b3e6",
  fontSize: 18,
  outline: "none",
  boxShadow: "0 2px 12px rgba(80,80,160,0.06)",
  background: "#fff",
  color: "#222",
  transition: "border 0.2s, box-shadow 0.2s",
};

const sectionToEndpoint = {
  today: "/today",
  yesterday: "/yesterday",
  tomorrow: "/tomorrow",
  "future-plan": "/future-plan",
  upcoming: "/upcoming",
  help: "/help",
};

function App() {
  const [selected, setSelected] = useState("home");
  const [newsList, setNewsList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [dateTime, setDateTime] = useState("");
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (selected === "home") return;
    setLoading(true);
    setError(null);
    let url = `http://localhost:8000${sectionToEndpoint[selected]}`;
    if (selected === "today" && search.trim()) {
      url += `?q=${encodeURIComponent(search.trim())}`;
    }
    fetch(url)
      .then((res) => {
        if (!res.ok) throw new Error("Network response was not ok");
        return res.json();
      })
      .then((data) => {
        setNewsList(data.news || []);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, [selected, search]);

  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      setDateTime(now.toLocaleString());
    };
    updateDateTime();
    const interval = setInterval(updateDateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={appStyle}>
      <Sidebar selected={selected} onSelect={setSelected} />
      <main style={mainStyle}>
        <div style={contentBoxStyle}>
          <header>
            <h1 style={headerStyle}>Xerago Daily Update</h1>
            <div style={subHeaderStyle}>Your daily dose of AI news, summarized simply.</div>
          </header>
          {selected === "home" && (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginTop: 20 }}>
              <h2 style={{ fontSize: 32, fontWeight: 700, color: "#222", marginBottom: 16 }}>Welcome!</h2>
              <p style={{ color: "#555", fontSize: 18, textAlign: "center", maxWidth: 500 }}>
                Explore the latest AI news, plans, and updates. Use the sidebar to navigate through today's highlights, past updates, future plans, and more.
              </p>
              <div style={{ marginTop: 32, color: "#888", fontSize: 16 }}>{dateTime}</div>
            </div>
          )}
          {selected !== "home" && (
            <>
              {selected === "today" && (
                <div style={searchBarStyle}>
                  <input
                    type="text"
                    placeholder="Search today's news..."
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                    style={searchInputStyle}
                  />
                </div>
              )}
              {loading && <p style={{ textAlign: "center", color: "#888" }}>Loading...</p>}
              {error && <p style={{ color: "#e00", textAlign: "center" }}>Error: {error}</p>}
              {!loading && !error && newsList.length > 0 && (
                <div>
                  {newsList.map((item, idx) => (
                    <NewsCard
                      key={idx}
                      title={item.title}
                      text={item.summary}
                      imageUrl={item.image_url}
                      dateTime={idx === 0 ? dateTime : undefined}
                    />
                  ))}
                </div>
              )}
              {!loading && !error && newsList.length === 0 && (
                <p style={{ textAlign: "center", color: "#888" }}>No news found.</p>
              )}
            </>
          )}
        </div>
      </main>
    </div>
  );
}

export default App; 